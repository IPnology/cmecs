<?php

	header("Location: web/user/");	

?>

