<!-- start slider -->
			<div id="da-slider" class="da-slider">
				<div class="da-slide">
					<h2>welcome to Casa Muebles</h2>
					<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.</p>
					<a href="../product" class="da-link">View Items</a>
					<div class="da-img"><img src="../../../include/web/images/slider1.png" alt="image01" /></div>
				</div>
				<div class="da-slide">
					<h2>welcome to Casa Muebles</h2>
					<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.</p>
					<a href="../product" class="da-link">View Items</a>
					<div class="da-img"><img src="../../../include/web/images/slider2.png" alt="image01" /></div>
				</div>
				<div class="da-slide">
					<h2>welcome to Casa Muebles</h2>
					<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.</p>
					<a href="../product" class="da-link">View Items</a>
					<div class="da-img"><img src="../../../include/web/images/slider3.png" alt="image01" /></div>
				</div>
				<div class="da-slide">
					<h2>welcome to Casa Muebles</h2>
					<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.</p>
					<a href="../product" class="da-link">View Items</a>
					<div class="da-img"><img src="../../../include/web/images/slider4.png" alt="image01" /></div>
				</div>
				<nav class="da-arrows">
					<span class="da-arrows-prev"></span>
					<span class="da-arrows-next"></span>
				</nav>
			</div>
<!----start-cursual---->
<div class="wrap">

</div>
