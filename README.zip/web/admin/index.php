<?php

	header("Location: account/");	

?>





