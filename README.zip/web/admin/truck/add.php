
<div class="wrapper">
<form action="process.php?action=add" method="POST">
	
	<label>NAME *</label>
	<input type="text" name="name" placeholder="Add Truck">
	<input type="submit" class="registerbtn" value="Add Truck">
</form>
</div>
	