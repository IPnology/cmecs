<div class="main_bg">
<div class="wrap">	
	<div class="main">
	<div class="single">
			<div class="left_content">
				<div class="span1_of_1_des" style="">
					<div class="desc1">
					<form action="process.php?action=create" method="POST">
						<label>CHOOSE TYPE:</label></br></br>
						<select name="type" class="select" required>
							<option value="">--Select type of wood--</option>
							<option>Narra</option>
							<option>Mahogany</option>
							<option>Oak</option>
							<option>Walnut</option>
						</select>
						</br>
						</br>
						<label>CHOOSE COLOR:</label></br></br>
						<select name="color" class="select" required>
							<option value="">--Select color--</option>
							<option>Black</option>
							<option>White</option>
							<option>Gray</option>
							<option>Red</option>
						</select>
						</br></br><input type="submit" class="myButton" value="Save">
					</form>
					 </div>
				</div>
				<div class="clear"></div>
	       </div>
	   <div class="clear"></div>
	</div>
</div>
</div>	
