create

<a href="?view=list">list</a>