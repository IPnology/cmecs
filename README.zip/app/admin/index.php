<?php

	header("Location: account/");	

?>

