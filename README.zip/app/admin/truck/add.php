
<div class="loginwrapper">
	<div style="width: 90.333%; margin-left: auto; margin-right: auto;">
		<form action="process.php?action=add" method="POST">
			</br>
			<div class="fwhole">
				<label>NAME *</label>
				<input type="text" name="name" placeholder="Add Truck"></br></br>
				<input type="submit" class="registerbtn" value="Add Truck">
			</div>
		</form>
	</div>
	</br>
</div>
	