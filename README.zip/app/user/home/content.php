<div id="da-slider" class="da-slider">
				<div class="da-slide">
					<h2>welcome to Casa Muebles</h2>
					<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.</p>
					<a href="../product" class="da-link">shop now</a>
					<div class="da-img"><img src="../../../include/web/images/slider1.png" alt="image01" /></div>
				</div>
				<div class="da-slide">
					<h2>welcome to Casa Muebles</h2>
					<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.</p>
					<a href="../product" class="da-link">shop now</a>
					<div class="da-img"><img src="../../../include/web/images/slider2.png" alt="image01" /></div>
				</div>
				<div class="da-slide">
					<h2>welcome to Casa Muebles</h2>
					<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.</p>
					<a href="../product" class="da-link">shop now</a>
					<div class="da-img"><img src="../../../include/web/images/slider3.png" alt="image01" /></div>
				</div>
				<div class="da-slide">
					<h2>welcome to Casa Muebles</h2>
					<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.</p>
					<a href="../product" class="da-link">shop now</a>
					<div class="da-img"><img src="../../../include/web/images/slider4.png" alt="image01" /></div>
				</div>
				<nav class="da-arrows">
					<span class="da-arrows-prev"></span>
					<span class="da-arrows-next"></span>
				</nav>
</div>
<div class="wrap">
<!----start-img-cursual---->
	<div id="owl-demo" class="owl-carousel">
		<div class="item" onclick="location.href='../product';">
			<div class="cau_left">
				<img class="lazyOwl" data-src="../../../include/web/images/c1.jpg" alt="Lazy Owl Image">
			</div>
			<div class="cau_left">
				<h4><a href="../product">Tables</a></h4>
				<a href="../product" class="btn">shop</a>
			</div>
		</div>	
		<div class="item" onclick="location.href='../product';">
			<div class="cau_left">
				<img class="lazyOwl" data-src="../../../include/web/images/c2.jpg" alt="Lazy Owl Image">
			</div>
			<div class="cau_left">
				<h4><a href="../product">Cabinet</a></h4>
				<a href="../product" class="btn">shop</a>
			</div>
		</div>	
		<div class="item" onclick="location.href='../product';">
			<div class="cau_left">
				<img class="lazyOwl" data-src="../../../include/web/images/c3.jpg" alt="Lazy Owl Image">
			</div>
			<div class="cau_left">
				<h4><a href="../product">Chairs</a></h4>
				<a href="../product" class="btn">shop</a>
			</div>
		</div>	
		<div class="item" onclick="location.href='../product';">
			<div class="cau_left">
				<img class="lazyOwl" data-src="../../../include/web/images/c2.jpg" alt="Lazy Owl Image">
			</div>
			<div class="cau_left">
				<h4><a href="../product">branded tees</a></h4>
				<a href="../product" class="btn">shop</a>
			</div>
		</div>	
		<div class="item" onclick="location.href='../product';">
			<div class="cau_left">
				<img class="lazyOwl" data-src="../../../include/web/images/c1.jpg" alt="Lazy Owl Image">
			</div>
			<div class="cau_left">
				<h4><a href="../product">branded shoes</a></h4>
				<a href="../product" class="btn">shop</a>
			</div>
		</div>	
		<div class="item" onclick="location.href='../product';">
			<div class="cau_left">
				<img class="lazyOwl" data-src="../../../include/web/images/c2.jpg" alt="Lazy Owl Image">
			</div>
			<div class="cau_left">
				<h4><a href="../product">branded tees</a></h4>
				<a href="../product" class="btn">shop</a>
			</div>
		</div>	
		<div class="item" onclick="location.href='../product';">
			<div class="cau_left">
				<img class="lazyOwl" data-src="../../../include/web/images/c3.jpg" alt="Lazy Owl Image">
			</div>
			<div class="cau_left">
				<h4><a href="../product">branded jeens</a></h4>
				<a href="../product" class="btn">shop</a>
			</div>
		</div>	
	</div>
	<!----//End-img-cursual---->
</div>