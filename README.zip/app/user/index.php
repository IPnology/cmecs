<?php

	header("Location: home/");	

?>

